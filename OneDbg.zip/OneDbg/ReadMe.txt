How to Install OneDbg:

1. Copy OneDbg.exe into WinDbg folder.
2. Set up _NT_SYMBOL_PATH environment variable. For example: C:\Symbols;srv*C:\Symbols*http://msdl.microsoft.com/download/symbols
3. Add extension dlls in the "Options->Configure Extensions" menu.
4. Enjoy!!!